# ThreadBack — AI Context-Preservation Workspace

> **Explore every thought. Never lose your thread.**

ThreadBack is an interactive frontend product that solves the context-loss problem when coding with AI assistants. Developers often interrupt their main objective to explore unfamiliar concepts (SideQuests). These side inquiries lead to further sub-questions, and eventually the primary task context is lost.

ThreadBack isolates side inquiries into visual query branches while preserving the immutable original mission, synthesizing key learnings, and generating 1-click continuation prompts ready to paste back into your IDE or LLM.

---

## 🌟 Key Features

1. **Mission Memory Root**
   - Anchors your primary mission title, objective, constraints, completed milestones, blocker, and immediate next action.

2. **SideQuest Branching Tree (From Reference Sketch)**
   - Interactive canvas with dotted-grid aesthetic inspired by Trido.
   - Directed bezier curves connecting the original mission to 1st query nodes and follow-up sub-queries.
   - Distinct visual hierarchy for Mission Roots, Branches, and Sub-queries.

3. **Signature Feature: "Return to Mission" Recovery Engine**
   - Prominent return button attached to every branch node and top navigation.
   - Synthesizes key takeaways from the investigated branch.
   - Generates a tailored, copyable continuation prompt with celebratory feedback (confetti & toast).
   - Keeps your context window clean and prevents prompt drift.

4. **Bottom Query Dock**
   - Direct inquiry dock matching the functional sketch: "this is part where the user inputs his queries".
   - Rapidly spawn sidequest branches attached to either the root mission or the selected branch.

5. **Branch Discussion & Learning Notes Drawer**
   - Collapsible panel with simulated conversational intelligence.
   - Code snippets, typing indicator, suggested follow-ups, and 1-click "Save as Learning Note".

6. **Local Persistence**
   - Missions, nested branches, messages, and notes automatically persist to browser `localStorage`.
   - "Reset Demo" button to restore initial sample Go CRUD API data anytime.

7. **Product Overview / Landing Page**
   - High-polish landing page with live interactive product preview, Before-vs-After comparison, and 3-step workflow.

---

## 🚀 Running the Project

The entire frontend application is located in the [`frontend`](./frontend) subfolder:

```bash
cd frontend
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

To verify the production build:
```bash
cd frontend
npm run build
```
