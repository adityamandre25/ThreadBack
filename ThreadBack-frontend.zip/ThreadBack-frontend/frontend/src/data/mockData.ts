import { Mission, QueryBranch } from '../types';

export const INITIAL_MISSION: Mission = {
  id: 'mission-go-crud',
  title: 'Build a CRUD API',
  objective: 'Build a CRUD API using Go and PostgreSQL.',
  constraints: [
    'Use Go',
    'Use PostgreSQL',
    'Keep the architecture simple',
    'Adhere to idiomatic project layout',
  ],
  completedSteps: [
    'Created the project structure',
    'Initialized the server',
  ],
  decisions: [
    'Selected standard net/http with Chi lightweight router',
    'Adopted database connection pooling via pgxpool',
  ],
  currentBlocker: 'Need to clarify connection pooling parameters and middleware pipeline order before writing database migrations.',
  nextAction: 'Implement database access',
  createdAt: '2026-10-09T09:00:00.000Z',
  updatedAt: '2026-10-09T10:15:00.000Z',
  status: 'active',
};

export const INITIAL_BRANCHES: QueryBranch[] = [
  // Branch 1: What is middleware?
  {
    id: 'branch-middleware',
    missionId: 'mission-go-crud',
    parentBranchId: null,
    title: 'What is middleware?',
    question: 'What is middleware in backend architecture and how does it wrap HTTP handlers?',
    expanded: true,
    createdAt: '2026-10-09T09:20:00.000Z',
    tags: ['Architecture', 'HTTP', 'Go'],
    learningNotes: [
      'Middleware wraps standard handlers to execute cross-cutting concerns (auth, logging, request tracking) without polluting domain logic.',
      'In Go, middleware follows the func(http.Handler) http.Handler signature.',
    ],
    messages: [
      {
        id: 'msg-mw-1',
        role: 'user',
        content: 'What is middleware in web backends, and how does it fit into our Go HTTP pipeline?',
        createdAt: '2026-10-09T09:20:05.000Z',
      },
      {
        id: 'msg-mw-2',
        role: 'assistant',
        content: `In web backends, **middleware** is reusable code that intercepts incoming HTTP requests before they reach your primary business handlers, and can also inspect or wrap responses before they return to the client.

In Go, middleware is typically structured as an adapter wrapping \`http.Handler\`:

\`\`\`go
func LoggingMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        start := time.Now()
        next.ServeHTTP(w, r)
        log.Printf("%s %s completed in %v", r.Method, r.URL.Path, time.Since(start))
    })
}
\`\`\`

It isolates cross-cutting concerns like logging, JWT authentication, CORS, and request timeout propagation away from your CRUD controllers.`,
        createdAt: '2026-10-09T09:20:30.000Z',
        useful: true,
      },
    ],
  },

  // Branch 1a (child of Branch 1): How does middleware validate requests?
  {
    id: 'branch-mw-validate',
    missionId: 'mission-go-crud',
    parentBranchId: 'branch-middleware',
    title: 'How does middleware validate requests?',
    question: 'How does middleware intercept and validate requests before hitting handlers or the database?',
    expanded: true,
    createdAt: '2026-10-09T09:35:00.000Z',
    tags: ['Security', 'Validation'],
    learningNotes: [
      'Middleware can validate headers, tokens, and payloads, returning early with 400 Bad Request before database access is triggered.',
    ],
    messages: [
      {
        id: 'msg-val-1',
        role: 'user',
        content: 'How does middleware validate requests before they reach the request handler or database?',
        createdAt: '2026-10-09T09:35:10.000Z',
      },
      {
        id: 'msg-val-2',
        role: 'assistant',
        content: `Validation middleware acts as a gatekeeper:

1. **Header & Auth Check:** Verifies \`Authorization: Bearer <token>\` or \`Content-Type: application/json\`.
2. **Early Rejection (Fail-Fast):** If the payload is invalid, the middleware writes an HTTP error status (e.g. 400 or 401) and returns **immediately without calling \`next.ServeHTTP(w, r)\`**.
3. **Context Injection:** When valid, the middleware injects parsed user claims or validated data into the \`r.Context()\` so downstream handlers don't repeat the work.

This guarantees your database access layer only receives sanitized, authorized requests.`,
        createdAt: '2026-10-09T09:35:35.000Z',
        useful: true,
      },
    ],
  },

  // Branch 1b (child of Branch 1): Middleware vs. handlers
  {
    id: 'branch-mw-vs-handlers',
    missionId: 'mission-go-crud',
    parentBranchId: 'branch-middleware',
    title: 'Middleware vs. handlers',
    question: 'What is the precise distinction between a middleware and an endpoint handler?',
    expanded: true,
    createdAt: '2026-10-09T09:42:00.000Z',
    tags: ['Patterns', 'Go'],
    learningNotes: [
      'Handlers implement the actual business transaction (e.g., CreateUser in Postgres). Middleware implements generic infrastructure wrapping all routes.',
    ],
    messages: [
      {
        id: 'msg-mvh-1',
        role: 'user',
        content: 'What is the architectural difference between middleware and a handler in Go?',
        createdAt: '2026-10-09T09:42:05.000Z',
      },
      {
        id: 'msg-mvh-2',
        role: 'assistant',
        content: `The distinction lies in **domain responsibility**:

- **Handler (The Destination):** Knows your business domain. It parses the specific input for \`POST /items\`, interacts with the PostgreSQL repository, and formats the domain JSON response.
- **Middleware (The Pipeline):** Domain-agnostic. It wraps any handler without caring about what domain entity is being manipulated. It handles timeouts, panic recovery, metric collection, and TLS enforcement.`,
        createdAt: '2026-10-09T09:42:25.000Z',
        useful: true,
      },
    ],
  },

  // Branch 2: What is database connection pooling?
  {
    id: 'branch-db-pooling',
    missionId: 'mission-go-crud',
    parentBranchId: null,
    title: 'What is database connection pooling?',
    question: 'What is database connection pooling in Go and PostgreSQL, and how does it prevent connection churn?',
    expanded: true,
    createdAt: '2026-10-09T09:55:00.000Z',
    tags: ['PostgreSQL', 'Performance', 'Database'],
    learningNotes: [
      'Connection pooling reuses a pool of warm TCP/TLS connections instead of creating a new socket handshake on every incoming API request.',
      'Go standard library sql.DB maintains a built-in pool configured via SetMaxOpenConns and SetMaxIdleConns.',
    ],
    messages: [
      {
        id: 'msg-pool-1',
        role: 'user',
        content: 'What is database connection pooling in Go and PostgreSQL?',
        createdAt: '2026-10-09T09:55:10.000Z',
      },
      {
        id: 'msg-pool-2',
        role: 'assistant',
        content: `Database connection pooling maintains a cache of active, authenticated database connections ready for reuse.

Creating a PostgreSQL connection involves TCP three-way handshakes, TLS negotiation, authentication, and allocating a dedicated backend process in PostgreSQL. Doing this on every HTTP request adds 20-100ms of latency per call.

With a pool:
\`\`\`go
db, err := sql.Open("pgx", connStr)
db.SetMaxOpenConns(25)
db.SetMaxIdleConns(10)
db.SetConnMaxLifetime(5 * time.Minute)
\`\`\`
Incoming requests borrow an idle connection in microseconds and return it when the query finishes.`,
        createdAt: '2026-10-09T09:55:38.000Z',
        useful: true,
      },
    ],
  },

  // Branch 2a (child of Branch 2): Why is pooling useful?
  {
    id: 'branch-why-pooling',
    missionId: 'mission-go-crud',
    parentBranchId: 'branch-db-pooling',
    title: 'Why is pooling useful?',
    question: 'Why is connection pooling especially useful for our Go CRUD API?',
    expanded: true,
    createdAt: '2026-10-09T10:05:00.000Z',
    tags: ['Scalability', 'PostgreSQL'],
    learningNotes: [
      'PostgreSQL spawns a backend process (~10MB RAM) per connection. Without pooling, traffic surges can exhaust server RAM and hit max_connections errors.',
    ],
    messages: [
      {
        id: 'msg-wpool-1',
        role: 'user',
        content: 'Why is pooling especially useful for our Go CRUD API with PostgreSQL?',
        createdAt: '2026-10-09T10:05:08.000Z',
      },
      {
        id: 'msg-wpool-2',
        role: 'assistant',
        content: `Connection pooling is essential for two major reasons:

1. **Memory & Concurrency Safety:** Each PostgreSQL backend process costs 5MB–10MB of RAM. If 500 concurrent HTTP requests arrive and open 500 direct connections, PostgreSQL will consume 5GB+ RAM and quickly crash or hit \`FATAL: sorry, too many clients already\`.
2. **Sub-millisecond Latency:** Instead of paying the 30ms TCP/TLS handshake tax on every CRUD request, queries execute against warm connections in under 1ms.

For our Go API, setting \`SetMaxOpenConns(25)\` ensures optimal throughput while protecting the database.`,
        createdAt: '2026-10-09T10:05:30.000Z',
        useful: true,
      },
    ],
  },
];

export const SECONDARY_SAMPLE_MISSION: Mission = {
  id: 'mission-auth-jwt',
  title: 'Implement Refresh Token Auth',
  objective: 'Design a secure JWT authentication system with rolling refresh tokens and Redis revocation.',
  constraints: [
    'Use HttpOnly secure cookies for refresh tokens',
    'Short-lived 15m access tokens',
    'Store token hashes in Redis',
  ],
  completedSteps: [
    'Designed token data model',
    'Implemented Argon2 password hashing',
  ],
  decisions: [
    'RS256 asymmetric signing over HS256 for microservice verification',
  ],
  currentBlocker: 'Determining token rotation race condition handling during concurrent client requests.',
  nextAction: 'Implement Redis token blacklisting middleware',
  createdAt: '2026-10-08T14:00:00.000Z',
  updatedAt: '2026-10-08T16:20:00.000Z',
  status: 'active',
};
