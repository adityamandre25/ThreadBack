import React from 'react';
import { ToastProvider } from './components/Toast';
import { TridoNavbar } from './components/trido/TridoNavbar';
import { TridoSidebar } from './components/trido/TridoSidebar';
import { FlowCanvas } from './components/canvas/FlowCanvas';
import { TridoBottomBar } from './components/trido/TridoBottomBar';
import { SideChatDrawer } from './components/SideChatDrawer';
import { RecoveryModal } from './components/RecoveryModal';
import { useCanvasStore } from './store/canvasStore';

function ThreadBackBoardApp() {
  const { openRecovery } = useCanvasStore();

  return (
    <div className="w-full h-screen bg-[#f1f3f6] flex flex-col font-sans overflow-hidden select-none">
      {/* 1. Trido Styled Top Navbar */}
      <TridoNavbar onOpenRecovery={() => openRecovery()} />

      {/* 2. Main Workspace Body (Sidebar + Board Canvas + Side Drawer) */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Sidebar (Trido Menu + "+ New Thread" button) */}
        <TridoSidebar />

        {/* Center Board Canvas Area */}
        <main className="flex-1 h-full relative overflow-hidden flex flex-col">
          <FlowCanvas />

          {/* Bottom Dock (ChatGPT-style Prompt Window + Trido Controls) */}
          <TridoBottomBar />
        </main>

        {/* Side Chat / Investigation Drawer (Streamed responses, text quotes, return CTA) */}
        <SideChatDrawer />
      </div>

      {/* 3. Signature Context Recovery Modal */}
      <RecoveryModal />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <ThreadBackBoardApp />
    </ToastProvider>
  );
}
