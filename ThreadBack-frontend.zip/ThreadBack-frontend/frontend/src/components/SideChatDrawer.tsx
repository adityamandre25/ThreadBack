import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  GitBranch, 
  Quote, 
  Bookmark, 
  Send, 
  ArrowUp, 
  CheckCircle2, 
  ChevronRight,
  Layers
} from 'lucide-react';
import { useCanvasStore } from '../store/canvasStore';
import { useToast } from './Toast';

export const SideChatDrawer: React.FC = () => {
  const { showToast } = useToast();
  const { 
    nodes, 
    selectedNodeId, 
    isChatDrawerOpen, 
    toggleChatDrawer, 
    openRecovery, 
    createBranchNode, 
    setContextSnippet 
  } = useCanvasStore();

  const [followUpText, setFollowUpText] = useState('');
  const contentRef = useRef<HTMLDivElement>(null);

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];
  const isRoot = selectedNode.id === 'root';
  const isGenerating = selectedNode.status === 'loading';

  // Handle text selection in answer to branch from quote
  const handleMouseUp = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 5) {
      const selected = selection.toString().trim();
      setContextSnippet(selected);
      showToast(`Selected text quote saved for next branch!`, 'info');
    }
  };

  const handleSendFollowUp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!followUpText.trim() || isGenerating) return;

    const query = followUpText.trim();
    setFollowUpText('');
    await createBranchNode(query, selectedNode.id);
  };

  if (!isChatDrawerOpen) return null;

  return (
    <aside className="w-80 md:w-96 lg:w-[420px] h-full bg-white/95 backdrop-blur-xl border-l border-slate-200/90 shadow-2xl flex flex-col z-30 select-none animate-in slide-in-from-right duration-200">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
            <GitBranch className="w-4 h-4 rotate-90" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">
              {isRoot ? 'Mission Anchor' : 'SideQuest Thread'}
            </span>
            <h3 className="text-xs font-bold text-slate-900 truncate max-w-[220px]" title={selectedNode.query}>
              {selectedNode.query}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => openRecovery(selectedNode.id)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-[10px] font-semibold shadow-xs hover:scale-105 active:scale-95 transition-all"
            title="Return to Mission"
          >
            <Sparkles className="w-3 h-3 text-indigo-200" />
            <span>Return</span>
          </button>
          <button
            onClick={() => toggleChatDrawer(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Conversation Stream */}
      <div 
        ref={contentRef} 
        onMouseUp={handleMouseUp}
        className="flex-1 overflow-y-auto p-4 space-y-4 text-xs"
      >
        {/* User Query Bubble */}
        <div className="flex flex-col items-end">
          <span className="text-[10px] text-slate-400 mb-1 px-1">You</span>
          <div className="p-3.5 rounded-2xl rounded-tr-xs bg-indigo-600 text-white leading-relaxed max-w-[90%] shadow-xs">
            {selectedNode.query}
          </div>
        </div>

        {/* Assistant Response Bubble */}
        <div className="flex flex-col items-start">
          <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-1 px-1">
            <span>ThreadBack Intelligence</span>
            {isGenerating && <span className="text-indigo-600 font-semibold">• Streaming...</span>}
          </div>

          <div className="p-4 rounded-2xl rounded-tl-xs bg-slate-50 border border-slate-200/90 text-slate-800 leading-relaxed max-w-[95%] shadow-xs whitespace-pre-wrap font-sans">
            {selectedNode.answer || (
              <div className="flex items-center gap-2 text-slate-400">
                <span className="w-3.5 h-3.5 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin"></span>
                <span>Generating isolated branch answer...</span>
              </div>
            )}
          </div>

          <p className="text-[10px] text-slate-400 mt-1 px-1">
            💡 Tip: Highlight any text in this answer to branch directly from that quote!
          </p>
        </div>

        {/* Learning Notes Preserved in this node */}
        {selectedNode.learningNotes && selectedNode.learningNotes.length > 0 && (
          <div className="p-3 bg-violet-50/70 border border-violet-200/70 rounded-xl space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-violet-700 block">
              Preserved Learning Takeaways
            </span>
            {selectedNode.learningNotes.map((note, idx) => (
              <p key={idx} className="text-[11px] text-violet-950 font-medium">
                • {note}
              </p>
            ))}
          </div>
        )}
      </div>

      {/* Side Chat Follow-up Input */}
      <div className="p-3 border-t border-slate-200/80 bg-white">
        <form onSubmit={handleSendFollowUp} className="flex items-center gap-2">
          <input
            type="text"
            value={followUpText}
            onChange={(e) => setFollowUpText(e.target.value)}
            disabled={isGenerating}
            placeholder={`Ask follow-up (spawns child node)...`}
            className="flex-1 text-xs p-2.5 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 bg-slate-50 focus:bg-white text-slate-800"
          />
          <button
            type="submit"
            disabled={!followUpText.trim() || isGenerating}
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white transition-all cursor-pointer"
            title="Create child branch"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </form>
      </div>
    </aside>
  );
};
