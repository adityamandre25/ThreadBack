import React from 'react';
import { 
  Square, 
  Clock, 
  DownloadCloud, 
  Settings, 
  HelpCircle, 
  Home, 
  Plus, 
  GitBranch, 
  Layers 
} from 'lucide-react';
import { useCanvasStore } from '../../store/canvasStore';

export const TridoSidebar: React.FC = () => {
  const { 
    activeSidebarItem, 
    setActiveSidebarItem, 
    isSidebarOpen, 
    startNewChat, 
    historyMissions, 
    nodes 
  } = useCanvasStore();

  if (!isSidebarOpen) return null;

  return (
    <aside className="w-64 h-full bg-[#f8f9fc] border-r border-slate-200/90 flex flex-col justify-between p-4 select-none shrink-0 transition-all">
      {/* Top Section */}
      <div className="space-y-4">
        {/* "+ New Chat" Button (Prominently placed as requested by user) */}
        <button
          onClick={() => startNewChat()}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white text-xs font-bold shadow-md shadow-indigo-600/20 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Thread / Mission</span>
        </button>

        {/* Trido Styled Navigation Items */}
        <nav className="space-y-1.5">
          {/* Papan Tulis / Canvas (Active: Deep Blue with yellow border icon like in Trido reference) */}
          <button
            onClick={() => setActiveSidebarItem('canvas')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
              activeSidebarItem === 'canvas'
                ? 'bg-[#1859c9] text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <div className={`p-1 rounded-md border-2 ${
              activeSidebarItem === 'canvas' ? 'border-[#facc15] text-[#facc15]' : 'border-slate-400 text-slate-500'
            }`}>
              <Square className="w-3.5 h-3.5" />
            </div>
            <span>Canvas Board</span>
          </button>

          {/* Riwayat / History */}
          <button
            onClick={() => setActiveSidebarItem('history')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
              activeSidebarItem === 'history'
                ? 'bg-[#1859c9] text-white'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4 text-slate-500" />
            <span className="flex-1 text-left">Thread History</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-200/80 text-slate-700">
              {historyMissions.length}
            </span>
          </button>

          {/* Ekspor & Impor / Export */}
          <button
            onClick={() => setActiveSidebarItem('export')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
              activeSidebarItem === 'export'
                ? 'bg-[#1859c9] text-white'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <DownloadCloud className="w-4 h-4 text-slate-500" />
            <span>Export & Save</span>
          </button>

          {/* Pengaturan / Settings */}
          <button
            onClick={() => setActiveSidebarItem('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
              activeSidebarItem === 'settings'
                ? 'bg-[#1859c9] text-white'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <Settings className="w-4 h-4 text-slate-500" />
            <span>Settings</span>
          </button>

          {/* Panduan / Guide */}
          <button
            onClick={() => setActiveSidebarItem('guide')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
              activeSidebarItem === 'guide'
                ? 'bg-[#1859c9] text-white'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-slate-500" />
            <span>User Guide</span>
          </button>
        </nav>
      </div>

      {/* Bottom Profile Pill (Trido style with Avatar 'G' / Developer) */}
      <div className="pt-3 border-t border-slate-200/70 flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-[#1859c9] text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
          G
        </div>
        <div className="min-w-0 flex-1">
          <h4 className="text-xs font-bold text-slate-900 truncate">Developer</h4>
          <p className="text-[10px] text-slate-500 truncate">Context Workspace</p>
        </div>
      </div>
    </aside>
  );
};
