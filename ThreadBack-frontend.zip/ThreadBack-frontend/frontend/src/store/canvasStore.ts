import { create } from 'zustand';
import { QNode, Mission } from '../types';
import { simulateAssistantReply } from '../utils/aiSimulator';

interface CanvasState {
  mission: Mission;
  nodes: QNode[];
  selectedNodeId: string | null;
  contextSnippet: string | null;
  isChatDrawerOpen: boolean;
  isRecoveryOpen: boolean;
  recoveryNodeId: string | null;
  activeSidebarItem: 'canvas' | 'history' | 'export' | 'settings' | 'guide';
  isSidebarOpen: boolean;
  historyMissions: { id: string; title: string; createdAt: string; nodeCount: number }[];

  // Actions
  selectNode: (id: string) => void;
  setContextSnippet: (snippet: string | null) => void;
  toggleChatDrawer: (open?: boolean) => void;
  openRecovery: (nodeId?: string) => void;
  closeRecovery: () => void;
  setActiveSidebarItem: (item: 'canvas' | 'history' | 'export' | 'settings' | 'guide') => void;
  toggleSidebar: () => void;
  updateMission: (mission: Partial<Mission>) => void;
  updateNodePosition: (id: string, position: { x: number; y: number }) => void;
  deleteNode: (id: string) => void;
  
  // New Chat / Fresh Thread
  startNewChat: (title?: string, objective?: string) => void;
  
  // Create and stream a new branch node
  createBranchNode: (query: string, parentId?: string | null, snippet?: string) => Promise<string>;
}

const INITIAL_CLEAN_MISSION: Mission = {
  id: 'mission-seed',
  title: 'My Project Mission',
  objective: 'Define your main task objective, architectural constraints, and next step.',
  constraints: ['Maintain modular architecture', 'Keep implementation clean'],
  completedSteps: ['Initialized project space'],
  decisions: [],
  currentBlocker: '',
  nextAction: 'Ask your first inquiry to start your context branch',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  status: 'active',
};

const INITIAL_ROOT_NODE: QNode = {
  id: 'root',
  parentId: null,
  query: 'Project Mission: Start Thread',
  answer: `**Welcome to ThreadBack.**

This is your immutable **Original Context Root**. Whenever you delve into side explorations, you will never lose this thread.

- Use the **ChatGPT input bar below** to ask your first question or explore an unfamiliar concept.
- Every inquiry automatically spawns an independent **SideQuest branch**.
- Click **Return to Mission** on any branch to synthesize key learnings and recover a continuation prompt for your IDE!`,
  status: 'done',
  position: { x: 80, y: 180 },
  createdAt: new Date().toISOString(),
  learningNotes: [],
};

export const useCanvasStore = create<CanvasState>((set, get) => ({
  mission: INITIAL_CLEAN_MISSION,
  nodes: [INITIAL_ROOT_NODE],
  selectedNodeId: 'root',
  contextSnippet: null,
  isChatDrawerOpen: false,
  isRecoveryOpen: false,
  recoveryNodeId: null,
  activeSidebarItem: 'canvas',
  isSidebarOpen: true,
  historyMissions: [
    { id: 'mission-seed', title: 'My Project Mission', createdAt: 'Today', nodeCount: 1 },
  ],

  selectNode: (id: string) => {
    set({ selectedNodeId: id });
  },

  setContextSnippet: (snippet: string | null) => {
    set({ contextSnippet: snippet });
  },

  toggleChatDrawer: (open?: boolean) => {
    set((state) => ({
      isChatDrawerOpen: open !== undefined ? open : !state.isChatDrawerOpen,
    }));
  },

  openRecovery: (nodeId?: string) => {
    set((state) => ({
      isRecoveryOpen: true,
      recoveryNodeId: nodeId || state.selectedNodeId || 'root',
    }));
  },

  closeRecovery: () => {
    set({ isRecoveryOpen: false });
  },

  setActiveSidebarItem: (item) => {
    set({ activeSidebarItem: item });
  },

  toggleSidebar: () => {
    set((state) => ({ isSidebarOpen: !state.isSidebarOpen }));
  },

  updateMission: (updated: Partial<Mission>) => {
    set((state) => ({
      mission: { ...state.mission, ...updated, updatedAt: new Date().toISOString() },
    }));
  },

  updateNodePosition: (id: string, position: { x: number; y: number }) => {
    set((state) => ({
      nodes: state.nodes.map((n) => (n.id === id ? { ...n, position } : n)),
    }));
  },

  deleteNode: (id: string) => {
    if (id === 'root') return;
    const { nodes, selectedNodeId } = get();

    const toDelete = new Set<string>([id]);
    let added = true;
    while (added) {
      added = false;
      nodes.forEach((n) => {
        if (n.parentId && toDelete.has(n.parentId) && !toDelete.has(n.id)) {
          toDelete.add(n.id);
          added = true;
        }
      });
    }

    const nextNodes = nodes.filter((n) => !toDelete.has(n.id));
    set({
      nodes: nextNodes,
      selectedNodeId: toDelete.has(selectedNodeId || '') ? 'root' : selectedNodeId,
    });
  },

  startNewChat: (title?: string, objective?: string) => {
    const missionTitle = title || 'New Task Mission';
    const missionObjective = objective || 'Fresh context preserved session.';
    const newMissionId = `mission-${Date.now()}`;

    const newMission: Mission = {
      id: newMissionId,
      title: missionTitle,
      objective: missionObjective,
      constraints: ['Preserve core principles', 'Stay focused on milestone'],
      completedSteps: ['Started new thread'],
      decisions: [],
      currentBlocker: '',
      nextAction: 'Ask initial sidequest inquiry',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'active',
    };

    const rootNode: QNode = {
      id: 'root',
      parentId: null,
      query: `Mission: ${missionTitle}`,
      answer: `**Context Anchor:** ${missionObjective}

Type any inquiry in the bottom chat bar to spawn your first learning branch without derailing this task.`,
      status: 'done',
      position: { x: 80, y: 180 },
      createdAt: new Date().toISOString(),
      learningNotes: [],
    };

    const { historyMissions } = get();
    set({
      mission: newMission,
      nodes: [rootNode],
      selectedNodeId: 'root',
      contextSnippet: null,
      isChatDrawerOpen: false,
      isRecoveryOpen: false,
      recoveryNodeId: null,
      historyMissions: [
        { id: newMissionId, title: missionTitle, createdAt: 'Just now', nodeCount: 1 },
        ...historyMissions,
      ],
    });
  },

  createBranchNode: async (query: string, parentId?: string | null, snippet?: string) => {
    const { nodes, selectedNodeId, mission } = get();
    const effectiveParentId = parentId !== undefined ? parentId : (selectedNodeId || 'root');
    const parentNode = nodes.find((n) => n.id === effectiveParentId) || nodes[0];

    // If root node was the initial placeholder, update mission title if it's the first query
    if (nodes.length === 1 && nodes[0].id === 'root' && mission.title === 'My Project Mission') {
      const derivedTitle = query.length > 30 ? query.slice(0, 28) + '...' : query;
      set((state) => ({
        mission: {
          ...state.mission,
          title: derivedTitle,
          objective: query,
        },
      }));
    }

    // Calculate position with generous spacing
    const siblings = nodes.filter((n) => n.parentId === parentNode.id);
    const newX = parentNode.position.x + 420;
    const newY = parentNode.position.y + siblings.length * 210 - (siblings.length > 0 ? 30 : 0);

    const newNodeId = `node-${Date.now()}`;
    const newNode: QNode = {
      id: newNodeId,
      parentId: parentNode.id,
      query,
      contextSnippet: snippet || undefined,
      answer: '',
      status: 'loading',
      position: { x: newX, y: Math.max(50, newY) },
      createdAt: new Date().toISOString(),
      learningNotes: [],
    };

    // Add node in loading state immediately
    set({
      nodes: [...nodes, newNode],
      selectedNodeId: newNodeId,
      contextSnippet: null,
      isChatDrawerOpen: true,
    });

    // Simulate async assistant response with progressive streaming
    const simResult = await simulateAssistantReply(query, parentNode.query);
    const fullText = simResult.reply;

    const words = fullText.split(' ');
    let currentText = '';

    for (let i = 0; i < words.length; i++) {
      currentText += (i === 0 ? '' : ' ') + words[i];
      set((state) => ({
        nodes: state.nodes.map((n) =>
          n.id === newNodeId
            ? { ...n, answer: currentText, status: i === words.length - 1 ? 'done' : 'loading' }
            : n
        ),
      }));
      await new Promise((r) => setTimeout(r, 18));
    }

    if (simResult.suggestedLearningNote) {
      set((state) => ({
        nodes: state.nodes.map((n) =>
          n.id === newNodeId
            ? { ...n, learningNotes: [simResult.suggestedLearningNote] }
            : n
        ),
      }));
    }

    return newNodeId;
  },
}));
